package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.event.ActionEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoPeliculaBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoAsiento;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoPelicula;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Named
@ViewScoped
public class FrmTipoPeliculaf extends FrmAbstractDataPersist<TipoPelicula> implements Serializable {
    @Inject
    TipoPeliculaBean tpBean;
    LazyDataModel<TipoPelicula> modelo;
    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoPelicula>() {
            @Override
            public String getRowKey(TipoPelicula object) {
                if (object != null && object.getIdTipoPelicula() != null) {
                    return object.getIdTipoPelicula().toString();
                }
                return null;
            }
            @Override
            public TipoPelicula getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoPelicula tipoPeliculaSeleccionado = getWrappedData().stream()
                            .filter(r -> rowKey.equals(r.getIdTipoPelicula().toString()))
                            .findFirst()
                            .orElse(null);
                    if (tipoPeliculaSeleccionado != null) {
                        registro = tipoPeliculaSeleccionado; // Asigna el registro seleccionado
                        estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoPeliculaSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }
            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return tpBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoPelicula> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return tpBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }




    @Override
    protected void createRegistro(TipoPelicula registro) {
        tpBean.create(registro);
    }

    @Override
    protected TipoPelicula updateRegistro(TipoPelicula registro) {
        return tpBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoPelicula registro) {
      tpBean.delete(registro);
    }

    @Override
    protected TipoPelicula createNewEntity() {
        return new TipoPelicula();
    }


    public TipoPeliculaBean getTpBean() {
        return tpBean;
    }

    public void setTpBean(TipoPeliculaBean tpBean) {
        this.tpBean = tpBean;
    }

    public LazyDataModel<TipoPelicula> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoPelicula> modelo) {
        this.modelo = modelo;
    }
}

