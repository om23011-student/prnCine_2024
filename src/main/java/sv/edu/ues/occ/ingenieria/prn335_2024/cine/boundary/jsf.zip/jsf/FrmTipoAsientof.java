package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.event.ActionEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoAsientoBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoAsiento;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Named
@ViewScoped
public class FrmTipoAsientof extends FrmAbstractDataPersist<TipoAsiento> implements Serializable {
     @Inject
     TipoAsientoBean taBean;
      LazyDataModel<TipoAsiento> modelo;
    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoAsiento>() {
            @Override
            public String getRowKey(TipoAsiento object) {
                if (object != null && object.getIdTipoAsiento() != null) {
                    return object.getIdTipoAsiento().toString();
                }
                return null;
            }
            @Override
            public TipoAsiento getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoAsiento tipoAsientoSeleccionado = getWrappedData().stream()
                            .filter(r -> rowKey.equals(r.getIdTipoAsiento().toString()))
                            .findFirst()
                            .orElse(null);
                    if (tipoAsientoSeleccionado != null) {
                        registro = tipoAsientoSeleccionado; // Asigna el registro seleccionado
                        estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoAsientoSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }
            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return taBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoAsiento> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return taBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }



    @Override
    protected void createRegistro(TipoAsiento registro) {
         taBean.create(registro);
    }

    @Override
    protected TipoAsiento updateRegistro(TipoAsiento registro) {
        return taBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoAsiento registro) {
      taBean.delete(registro);
    }

    @Override
    protected TipoAsiento createNewEntity() {
        return new TipoAsiento();
    }

    public TipoAsientoBean getTaBean() {
        return taBean;
    }

    public void setTaBean(TipoAsientoBean taBean) {
        this.taBean = taBean;
    }

    public LazyDataModel<TipoAsiento> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoAsiento> modelo) {
        this.modelo = modelo;
    }
}
