package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.event.ActionEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoPagoBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoPago;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoReserva;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
@Named
@ViewScoped
public class FrmTipoPagof extends FrmAbstractDataPersist<TipoPago> implements Serializable {
    @Inject
    TipoPagoBean dataBean;
    LazyDataModel<TipoPago> modelo;
    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoPago>() {
            @Override
            public String getRowKey(TipoPago object) {
                if (object != null && object.getIdTipoPago() != null) {
                    return object.getIdTipoPago().toString();
                }
                return null;
            }
            @Override
            public TipoPago getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoPago tipoPagoSeleccionado = getWrappedData().stream()
                            .filter(r -> rowKey.equals(r.getIdTipoPago().toString()))
                            .findFirst()
                            .orElse(null);
                    if (tipoPagoSeleccionado != null) {
                        registro = tipoPagoSeleccionado; // Asigna el registro seleccionado
                        estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoPagoSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }
            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return dataBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoPago> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return dataBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }

    @Override
    protected void createRegistro(TipoPago registro) {
        dataBean.create(registro);
    }

    @Override
    protected TipoPago updateRegistro(TipoPago registro) {
        return dataBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoPago registro) {
      dataBean.delete(registro);
    }

    @Override
    protected TipoPago createNewEntity() {
        return new TipoPago();
    }

    public TipoPagoBean getDataBean() {
        return dataBean;
    }

    public void setDataBean(TipoPagoBean dataBean) {
        this.dataBean = dataBean;
    }

    public LazyDataModel<TipoPago> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoPago> modelo) {
        this.modelo = modelo;
    }

}
