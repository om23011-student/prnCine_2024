package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

public enum ESTADO_CRUD {
    CREAR,MODIFICAR,NINGUNO
}
