package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoReservaBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoReserva;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Named
@ViewScoped
public class FrmTipoReservaf extends FrmAbstractDataPersist<TipoReserva> implements Serializable {
    @Inject
    TipoReservaBean dataBean;
    LazyDataModel<TipoReserva> modelo;
    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoReserva>() {
            @Override
            public String getRowKey(TipoReserva object) {
                if (object != null && object.getIdTipoReserva() != null) {
                    return object.getIdTipoReserva().toString();
                }
                return null;
            }
            @Override
            public TipoReserva getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoReserva tipoReservaSeleccionado = getWrappedData().stream()
                            .filter(r -> rowKey.equals(r.getIdTipoReserva().toString()))
                            .findFirst()
                            .orElse(null);
                    if (tipoReservaSeleccionado != null) {
                        registro = tipoReservaSeleccionado; // Asigna el registro seleccionado
                        estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoReservaSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }
            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return dataBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoReserva> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return dataBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }
    @Override
    protected void createRegistro(TipoReserva registro) {
      dataBean.create(registro);
    }

    @Override
    protected TipoReserva updateRegistro(TipoReserva registro) {
        return dataBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoReserva registro) {
dataBean.delete(registro);
    }

    @Override
    protected TipoReserva createNewEntity() {
        registro.setActivo(true);
        return new TipoReserva();
    }

    public TipoReservaBean getDataBean() {
        return dataBean;
    }

    public void setDataBean(TipoReservaBean dataBean) {
        this.dataBean = dataBean;
    }

    public LazyDataModel<TipoReserva> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoReserva> modelo) {
        this.modelo = modelo;
    }
}

