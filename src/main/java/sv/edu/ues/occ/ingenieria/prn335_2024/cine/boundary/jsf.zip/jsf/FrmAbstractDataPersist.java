package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.ActionEvent;
import jakarta.inject.Inject;

import java.io.Serializable;

public abstract class FrmAbstractDataPersist<T> implements Serializable {
    @Inject
    protected FacesContext facesContext;
    protected ESTADO_CRUD estado;
    protected T registro;


    // Métodos abstractos para implementar en clases hijas
    protected abstract void createRegistro(T registro);
    protected abstract T updateRegistro(T registro);
    protected abstract void deleteRegistro(T registro);

    public void btnCrearHandler(ActionEvent actionEvent) {
        try {
            createRegistro(registro);
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Datos guardados exitosamente", null));
            reset();
        } catch (Exception e) {
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
            e.printStackTrace();
        }
    }

    public void btnNuevoHandler(ActionEvent actionEvent) {
         registro = createNewEntity();
         estado = ESTADO_CRUD.CREAR;
    }

    public void btnModificarHandler(ActionEvent actionEvent) {
        try {
            T actualizado = updateRegistro(registro);
            if (actualizado != null) {
                facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Registro modificado con éxito."));
                reset();
            } else {
                facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo modificar el registro."));
            }
        } catch (Exception e) {
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al modificar el registro."));
            e.printStackTrace();
        }
    }

    public void btnEliminarHandler(ActionEvent actionEvent) {
        try {
            deleteRegistro(registro);
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Registro eliminado con éxito."));
            reset();
        } catch (Exception e) {
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo eliminar el registro."));
            e.printStackTrace();
        }
    }

    public void btnCancelarHandler(ActionEvent actionEvent) {
        reset();
    }

    protected void reset() {
        registro = null;
        estado = ESTADO_CRUD.NINGUNO;
    }



    public T getRegistro() {
        return registro;
    }

    public void setRegistro(T registro) {
        this.registro = registro;
    }

    public ESTADO_CRUD getEstado() {
        return estado;
    }

    public void setEstado(ESTADO_CRUD estado) {
        this.estado = estado;
    }

    // Método abstracto para crear una nueva instancia de la entidad en clases hijas
    protected abstract T createNewEntity();
}
