package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.event.ActionEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoProductoBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoProducto;


import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Named
@ViewScoped
public class FrmTipoProductof extends FrmAbstractDataPersist<TipoProducto> implements Serializable {

    @Inject
    TipoProductoBean tprBean;
    LazyDataModel<TipoProducto> modelo;

    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoProducto>() {
            @Override
            public String getRowKey(TipoProducto object) {
                if (object != null && object.getIdTipoProducto() != null) {
                    return object.getIdTipoProducto().toString();
                }
                return null;
            }
            @Override
            public TipoProducto getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoProducto tipoProductoSeleccionado = getWrappedData().stream()
                            .filter(r -> rowKey.equals(r.getIdTipoProducto().toString()))
                            .findFirst()
                            .orElse(null);
                    if (tipoProductoSeleccionado != null) {
                        registro = tipoProductoSeleccionado; // Asigna el registro seleccionado
                        estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoProductoSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }
            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return tprBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoProducto> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return tprBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }





    @Override
    protected void createRegistro(TipoProducto registro) {
        tprBean.create(registro);
    }

    @Override
    protected TipoProducto updateRegistro(TipoProducto registro) {
        return tprBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoProducto registro) {
        tprBean.delete(registro);
    }

    @Override
    protected TipoProducto createNewEntity() {
        return new TipoProducto();
    }


    public TipoProductoBean getTprBean() {
        return tprBean;
    }

    public void setTprBean(TipoProductoBean tprBean) {
        this.tprBean = tprBean;
    }

    public LazyDataModel<TipoProducto> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoProducto> modelo) {
        this.modelo = modelo;
    }
}

