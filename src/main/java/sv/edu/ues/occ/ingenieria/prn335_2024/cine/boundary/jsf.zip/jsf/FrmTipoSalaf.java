package sv.edu.ues.occ.ingenieria.prn335_2024.cine.boundary.jsf;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.event.ActionEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.control.TipoSalaBean;
import sv.edu.ues.occ.ingenieria.prn335_2024.cine.entity.TipoSala;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


@Named
@ViewScoped
public class FrmTipoSalaf extends FrmAbstractDataPersist<TipoSala> implements Serializable {
    @Inject
    TipoSalaBean tsBean;
    LazyDataModel<TipoSala> modelo;

    @PostConstruct
    public void inicializar() {
        estado = ESTADO_CRUD.NINGUNO;
        modelo = new LazyDataModel<TipoSala>() {
            @Override
            public String getRowKey(TipoSala object) {
                if (object != null && object.getIdTipoSala() != null) {
                    return object.getIdTipoSala().toString();
                }
                return null;
            }
            @Override
            public TipoSala getRowData(String rowKey) {
                if (rowKey != null && getWrappedData() != null) {
                    TipoSala tipoSalaSeleccionado = getWrappedData().stream().filter(r -> rowKey.equals(r.getIdTipoSala().toString())).findFirst().orElse(null);
                    if (tipoSalaSeleccionado != null) {
                            registro = tipoSalaSeleccionado; // Asigna el registro seleccionado
                            estado = ESTADO_CRUD.MODIFICAR; // Cambia el estado a modificar
                    }
                    return tipoSalaSeleccionado; // Devuelve el registro seleccionado
                }
                return null;
            }

            @Override
            public int count(Map<String, FilterMeta> map) {
                try {
                    return tsBean.count().intValue();
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudo contar los registros.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return 0;
            }
            @Override
            public List<TipoSala> load(int desde, int max, Map<String, SortMeta> sortBy, Map<String, FilterMeta> filters) {
                try {
                    if (desde >= 0 && max > 0) {
                        return tsBean.findRange(desde, max);
                    }
                } catch (Exception e) {
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error", "No se pudieron cargar los datos.");
                    facesContext.addMessage(null, message);
                    e.printStackTrace();
                }
                return List.of();
            }
        };
    }
    @Override
    protected void createRegistro(TipoSala registro) {
        tsBean.create(registro);
    }

    @Override
    protected TipoSala updateRegistro(TipoSala registro) {
        return tsBean.update(registro);
    }

    @Override
    protected void deleteRegistro(TipoSala registro) {
         tsBean.delete(registro);
    }

    @Override
    protected TipoSala createNewEntity() {
        return new TipoSala();
    }

    public TipoSalaBean getTsBean() {
        return tsBean;
    }

    public void setTsBean(TipoSalaBean tsBean) {
        this.tsBean = tsBean;
    }
    public LazyDataModel<TipoSala> getModelo() {
        return modelo;
    }

    public void setModelo(LazyDataModel<TipoSala> modelo) {
        this.modelo = modelo;
    }

}

